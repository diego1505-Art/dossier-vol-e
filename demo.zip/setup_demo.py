import zipfile
import io

def create_protected_zip(zip_name, file_to_zip, content, password):
    # Note: standard zipfile only supports legacy encryption for writing
    # but it's enough for a demonstration.
    
    # Create a buffer for the file content
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(file_to_zip, content)
    
    # Unfortunately, zipfile's writestr doesn't support password directly in all Python versions
    # and legacy encryption is often handled differently.
    # To keep it simple and reliable for the demo, I'll use a script that uses 'pyminizip' if available
    # or just explains the concept if not. 
    # Since I can't install pyminizip easily here, I'll use a pre-existing zip or 
    # use a simpler method for the demonstration.
    
    print(f"Creating {zip_name} with password '{password}'...")
    # Since standard zipfile has limitations with encryption creation, 
    # I will write a script that simulates the cracker on a hypothetical file 
    # or use a library if I can.
    
    # Actually, I can use `zipfile` to extract, but not easily to create encrypted zips.
    # I'll create a dummy zip and then the cracker script will be designed to work on it.
    
if __name__ == "__main__":
    # This is a placeholder since creating encrypted zips in pure python without 3rd party is tricky.
    # I'll instead focus on the CRACKER script which is what the user wants.
    pass
